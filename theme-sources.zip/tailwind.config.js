module.exports = {
  presets: [require('./aem-blueprint/tailwind.config')],
  theme: {
    extend: {},
  },
  variants: {},
  plugins: [],
  purge: {
    enabled: true,
    content: [
      './src/styles/index.json',
      './src/template/policies.json',
      './src/components/**/**/*.js',
      './src/components/**/**/*.css',
      './src/site/js/*.js',
      './src/site/css/*.css',
      './src/styles/index.json',
    ],
    css: ['./src/main.css'],
  },
};
