module.exports = [
  require("./background-color"),
  require("./backdrop-filter-blur"),
  require("./animation-fade"),
  require("./animation-zoom"),
  require("./animation-duration"),
  require("./animation-delay"),
  require("./flex-grow"),
  require("./max-width"),
  require("./rounded"),
]