module.exports = {
  plugins: {
    'postcss-easy-import': { prefix: '_' },
    'postcss-nested': {},
    'postcss-at-rules-variables': {},
    'tailwindcss': {},
    autoprefixer: {},
    cssnano: {},
  }
};